drop table if exists USERS;
create table USERS (
	id integer primary key
	name text not null
	lastAccess not null
);